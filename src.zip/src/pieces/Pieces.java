package pieces;

import board.Board;
import board.Cell;

/**
 * an abstract class for all piece types such as pieces.Bishop
 * @author Yifei Li, yl1160,
 *         Yifan Zhang, yz745
 *
 */
public abstract class Pieces implements Cloneable{
    private String type;
    private boolean isWhite;
    //private boolean isKilled;
    private String promoteRole = null;
    private boolean hasMoved = false;
    private boolean isFirstmove = true;
    private boolean promoted = false;
    private boolean castlingDone = false;
    /**
     * constructor of piece class that initialize a piece with the color status and capture status
     * @param isWhite isWhite indicate weather a piece is white or not

     * @author yifeili
     */
    public Pieces(String type,boolean isWhite,String promoteRole,boolean hasMoved,boolean isFirstmove,boolean promoted ){
        this.type = type;
        this.isWhite = isWhite;
        this.promoteRole = promoteRole;
        this.hasMoved = hasMoved;
        this.isFirstmove = isFirstmove;
        this.promoted = promoted;

    }
    public void setType(String type){this.type = type;}
    public String getType(){return type;}
    public void setWhite(boolean white) {
        isWhite = white;
    }
    public boolean isWhite(){
        return isWhite;
    }
    public String getPromoteRole() {return promoteRole;}

    public void setPromoteRole(String promoteRole) {
        this.promoteRole = promoteRole;
    }
    public void setCastlingDone(boolean castlingDone) {
        this.castlingDone = castlingDone;
    }

    public boolean getCastlingDone() {
        return castlingDone;
    }


    public void setHasMoved(boolean hasMoved){
        this.hasMoved = hasMoved;
    }
    public boolean getHasMoved(){
        return this.hasMoved;
    }
    public void setFirstmove(boolean firstmove) {
        isFirstmove = firstmove;
    }
    public boolean getFirstmove() {
        return isFirstmove;
    }
    public void setPromoted(boolean promoted) {
        this.promoted = promoted;
    }
    public boolean getPromoted() {
        return promoted;
    }
    /**
     * an abstract method that detect weather a movement is valid for certain piece.
     * @param board board pass the current game board
     * @param start start pass the starting cell for certain movement
     * @param dest  dest pass the end cell for certain movement
     * @return true if the movement is valid, false otherwise.
     */
    public abstract boolean rule(Board board, Cell start, Cell dest, String promote);
    //public abstract boolean checkValid(Board board, Cell start, Cell dest, String promote);
    public abstract Pieces clone();



}
